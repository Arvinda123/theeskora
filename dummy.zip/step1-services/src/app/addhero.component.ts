 
import { Component, EventEmitter, Output } from "@angular/core";
import { UserServices } from "./user.services";
 
@Component({
    selector : 'app-addhero',
    template : `
    <h2>Add Hero</h2>
    <div class="col-12">
        <label for="herotitle" class="form-label">Title</label>
        <input [(ngModel)]="hero.title" type="text" class="form-control" id="herotitle" placeholder="Hero's Title">
    </div>
    <div class="row">
        <div class="col-md-6">
            <label for="herofirstname" class="form-label">First Name</label>
            <input [(ngModel)]="hero.firstname" type="text" class="form-control" id="herofirstname" placeholder="First Name">
        </div>
        <div class="col-md-6">
            <label for="herolastname" class="form-label">Last Name</label>
            <input [(ngModel)]="hero.lastname" type="text" class="form-control" id="herolastname" placeholder="Last Name">
        </div>
    </div>
    <div class="col-12 mb-3">
        <label for="herocity" class="form-label">Hero's City</label>
        <input [(ngModel)]="hero.city" type="text" class="form-control" id="herocity" placeholder="Place of Birth">
    </div>
    <div class="col-12">
        <button (click)="addHero()" type="submit" class="btn btn-primary">Add Hero</button>
    </div>
    `
})
export class AddHeroComp{
    hero = {
        title : '',
        firstname : '',
        lastname : '',
        city : ''
    }
    constructor(private us:UserServices){}
    @Output() heroAddedEvent:EventEmitter<any> = new EventEmitter();
    addHero(){
        this.us.postUser(this.hero).subscribe(res=>{
            this.hero = {
                title : '',
                firstname : '',
                lastname : '',
                city : ''
            }
            this.heroAddedEvent.emit();
        });
    }
 
}
 