 
import { Component } from '@angular/core';
import { UserServices } from './user.services';
 
@Component({
  selector: 'app-root',
  template: `
    <div class="container">
    <h1>IBM</h1>
    <button>Template</button>
    <button>Evaluation</button>
    <button>Contact us</button>
       <app-addhero *ngIf="!showedit" (heroAddedEvent)="heroAddedHandler()"></app-addhero>
       <app-edithero [editHeroInfo]="editHero" (updateSuccessEvent)="updateSuccessHandler($event)"  *ngIf="showedit"></app-edithero>
       <app-grid [gridData]="appdata" 
       (heroDeletedEvent)="heroDeletedHandler($event)" 
       (heroEditEvent)="editSelectedHeroEvent($event)"></app-grid>
    </div>
 
  `,
  styles: []
})
export class AppComponent {
  title = 'step1-services';
  appdata:any = [];
  editHero:any = {};
  showedit = false;
  constructor(private us:UserServices){}
  refresh(){
    this.us.getUsers()
    .subscribe(res=> this.appdata = res); 
  }
  ngOnInit(){
    this.refresh();
  }
  heroAddedHandler(){
    this.refresh();
  }
  heroDeletedHandler(evt:any){
    this.refresh();
    alert(evt.deleted+" was deleted")
  }
  editSelectedHeroEvent(event:any){
    this.editHero = event;
    this.showedit = true;
  }  
  updateSuccessHandler(event:any){
    this.showedit = false;
    this.refresh();
  }
}
 