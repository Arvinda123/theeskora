
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from "@angular/common/http"
 
import { AppComponent } from './app.component';
import { UserServices } from './user.services';
import { GridComp } from './grid.component';
import { AddHeroComp } from './addhero.component';
import { FormsModule } from '@angular/forms';
import { EditHeroComp } from './edithero.component';
 
@NgModule({
  declarations: [ AppComponent, GridComp, AddHeroComp, EditHeroComp ],
  imports: [ BrowserModule, HttpClientModule, FormsModule ],
  providers: [ UserServices ],
  bootstrap: [AppComponent]
})
export class AppModule { }