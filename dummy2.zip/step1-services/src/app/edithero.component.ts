 
import { Component, EventEmitter, Input, Output } from "@angular/core";
import { UserServices } from "./user.services";
 
@Component({
    selector : 'app-edithero',
    template : `
    <h2>Edit Hero</h2>
    <div class="col-12">
        <label for="herotitle" class="form-label">Title</label>
        <input [(ngModel)]="editHeroInfo.title" type="text" class="form-control" id="herotitle" >
    </div>
    <div class="row">
        <div class="col-md-6">
            <label for="herofirstname" class="form-label">First Name</label>
            <input [(ngModel)]="editHeroInfo.firstname" type="text" class="form-control" id="herofirstname" >
        </div>
        <div class="col-md-6">
            <label for="herolastname" class="form-label">Last Name</label>
            <input [(ngModel)]="editHeroInfo.lastname" type="text" class="form-control" id="herolastname" >
        </div>
    </div>
    <div class="col-12 mb-3">
        <label for="herocity" class="form-label">Hero's City</label>
        <input [(ngModel)]="editHeroInfo.city" type="text" class="form-control" id="herocity" >
    </div>
    <div class="col-12">
        <button (click)="updateHero()" type="submit" class="btn btn-primary">Update Hero Info</button>
    </div>
    `
})
export class EditHeroComp{
   @Input() editHeroInfo = {
        id : '',
        title : '',
        firstname : '',
        lastname : '',
        city : ''
    }
    @Output() updateSuccessEvent:EventEmitter<any> = new EventEmitter();
    constructor(private us:UserServices){}
    updateHero(){
        this.us.updateSelectedUser(this.editHeroInfo).subscribe( res => this.updateSuccessEvent.emit(res))
    }
 
}
 